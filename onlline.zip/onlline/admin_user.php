<?php

include('session.php');

$id = $_GET['id'];
$get_administrator = mysqli_query($con, "select * from users where user_id ='$id'");

$s = "select * from profile_pics where user_id = '$id'";
$ex = mysqli_query($con, $s);
if(mysqli_num_rows($ex) == 0){

  $image = 'img/avatar-1.jpg';

}else{
  while($r = mysqli_fetch_assoc($ex)){
  $name = $r['file'];
  }
  $image = 'img/profile/'.$name ;
}

if(isset($_POST['back'])){

  echo "<script>window.location='administrators.php'</script>";

}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Noticeboard | User Details</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Font Awesome CDN-->
    <!-- you can replace it by local Font Awesome-->
    <script src="js/99347ac47f.js"></script>
    <script src="js/jquery.cropit.js"></script>
    <!-- Font Icons CSS-->
    <link rel="stylesheet" href="css/icons.css">
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
    <style type="text/css">
    .hovereffect {
      width: 100%;
      height: 100%;
      float: left;
      overflow: hidden;
      position: relative;
      text-align: center;
      cursor: default;
    }


    .hovereffect:hover .overlay {
      background-color: rgba(170,170,170,0.4);
    }

    .hovereffect h2, .hovereffect img {
      -webkit-transition: all 0.4s ease-in-out;
      transition: all 0.4s ease-in-out;
    }

    .hovereffect img {
      display: block;
      position: relative;
      -webkit-transform: scale(1.1);
      -ms-transform: scale(1.1);
      transform: scale(0.9);
    }

    .hovereffect:hover img {
      -webkit-transform: scale(1);
      -ms-transform: scale(1);
      transform: scale(1);
    }

    .hovereffect h2 {
      text-transform: uppercase;
      color: #fff;
      text-align: center;
      position: relative;
      font-size: 17px;
      padding: 10px;
      background: rgba(0, 0, 0, 0.6);
    }

    .hovereffect a.info {
      display: inline-block;
      text-decoration: none;
      padding: 7px 14px;
      text-transform: uppercase;
      color: #fff;
      border: 1px solid #fff;
      margin: 50px 0 0 0;
      background-color: transparent;
      opacity: 0;
      filter: alpha(opacity=0);
      -webkit-transform: scale(1.5);
      -ms-transform: scale(1.5);
      transform: scale(1.5);
      -webkit-transition: all 0.4s ease-in-out;
      transition: all 0.4s ease-in-out;
      font-weight: normal;
      height: 85%;
      width: 85%;
      position: absolute;
      top: -20%;
      left: 8%;
      padding: 70px;
    }
    .file {
      visibility: hidden;
      position: absolute;
    }

    .cropit-preview {
        background-color: #f8f8f8;
        background-size: cover;
        border: 1px solid #ccc;
        border-radius: 3px;
        margin-top: 7px;
        width: 250px;
        height: 250px;
      }

      .cropit-preview-image-container {
        cursor: move;
      }

      .image-size-label {
        margin-top: 10px;
      }

      input {
        display: block;
      }

      button[type="submit"] {
        margin-top: 10px;
      }

      #result {
        margin-top: 10px;
        width: 900px;
      }

      #result-data {
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        word-wrap: break-word;
      }
  
  </style>

<?php

?>
  </head>
  <body>
    <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <div class="sidenav-header-inner text-center"><img src="<?php echo $image;?>" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5 text-uppercase"><?php echo $login_session_name." ".$login_session_surname;?></h2><span class="text-uppercase">Administrator</span>
          </div>
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>O</strong><strong class="text-primary">N</strong></a></div>
        </div>
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li><a href="home.php"> <i class="icon-home"></i><span>Home</span></a></li>
            <li> <a href="announcements.php"><i class="icon-form"></i><span>Announcements</span></a></li>   
            <li> <a href="create_account.php"> <i class="icon-interface-windows"></i><span>Create Account</span></a></li>
            <li> 
              <a href="#pages-nav-list" data-toggle="collapse" aria-expanded="false"><i class="icon-screen"></i><span>System Users</span>
                <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
              <ul id="pages-nav-list" class="collapse list-unstyled">
                <li class="active"> <a href="administrators.php">Administrators</a></li>
                <li> <a href="students.php">Students</a></li>
              </ul>
            </li>
            <li> <a href="profile.php"> <i class="icon-user"></i><span>User Profile</span></a></li>
            <li> 
               <a href="#pages-nav-list1" data-toggle="collapse" aria-expanded="false"> <i class="icon-list-1"></i><span>Reports</span>  <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div>
               </a>
               <ul id="pages-nav-list1" class="collapse list-unstyled">
                <li> <a href="admin_reports.php">Admin Reports</a></li>
                <li> <a href="student_reports.php">Student Reports</a></li>
              </ul>
            </li>
            <li> <a href="logout.php"> <i class="fa fa-sign-out"></i><span> Logout</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="page forms-page">
      <!-- navbar-->
      <header class="header">
        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="home.php" class="navbar-brand">
                  <div class="brand-text hidden-sm-down"><span>Administrator's </span><strong class="text-primary"> Dashboard</strong></div></a></div>
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a href="logout.php" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item"><a href="administrators.php">Administrators</a></li>
            <li class="breadcrumb-item active">User Details</li>
          </ul>
        </div>
      </div>
      <section class="forms">
        <div class="container-fluid">
          <header> 
            <h1 class="h3 display">User Profile</h1>
          </header>
          <div class="row">
                    <?php
                    while($row = mysqli_fetch_assoc($get_administrator)):;
                      ?>
            <div class="col-lg-8">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display"></h2>
                </div>
                <div class="card-block">
                  <form method="post" action="" class="form-horizontal">
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Username<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="username" value="<?php echo $row['username'];?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">First Name<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="firstname" value="<?php echo $row['firstname'];?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Surname<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="surname" value="<?php echo $row['surname'];?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Email<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="email_address" value="<?php echo $row['email_address'];?>" class="form-control" readonly>
                        <span><font style="color:red;">Note*</font> Changing your email address will automatically sign you out.</span>
                      </div>
                    </div>
                    <div class="line"></div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Role<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="role" value="<?php echo $row['role'];?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="line"></div>
                    <div class="form-group row">
                      <div class="col-sm-4 offset-sm-2">
                        <button type="submit" name="back" class="btn btn-secondary">&laquo; Back</button>
                      </div>
                    </div>
                  <?php endwhile;?>
                  </form>
                </div>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display"></h2>
                </div>
                <div class="card-block">
                   <!-- new code for profile pic-->  
                <div class="text-center">
                  <div class="hovereffect">
                      <img src="<?php echo $image;?>" id="pop" class="center-block img-circle img-responsive" height="350" width="350">
                      <!-- <span><font style="color:red;">Note*</font> Click on image to upload profile pic. Image must have equal dimensions to display properly.</span> -->
                  </div><br>
                </div>
                </div>
        <!-- end new code -->
              </div>
            </div>
          </form>
          </div>
        </div>
      </section>
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Kraphtbox &copy; 2017</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Design by <a href="https://bootstrapious.com" class="external">Bootstrapious</a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>

    <!-- Javascript files-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script>
      $("#pop").on("click", function() {
      $('#imagepreview').attr('src', $('#imageresource').attr('src')); // here asign the image to the modal when the user click the enlarge link
      $('#imagemodal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
      });
    </script>

    <script>
  $('#image-cropper').cropit();

// In the demos I'm passing in an imageState option
// so it renders an image by default:
// $('#image-cropper').cropit({ imageState: { src: { imageSrc } } });

// Exporting cropped image
    $('.download-btn').click(function() {
      var imageData = $('#image-cropper').cropit('export');
      window.open(imageData);
    });
  </script>

    <script type="text/javascript">
      $(document).on('click', '.browse', function(){
      var file = $(this).parent().parent().parent().find('.file');
      file.trigger('click');
    });
    $(document).on('change', '.file', function(){
      $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
    });
    </script>


    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/front.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <!---->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='//www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>
  </body>
</html>