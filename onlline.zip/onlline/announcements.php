<?php

include('session.php');

$get_announcements = mysqli_query($con, "select * from announcement order by today_date desc");
$today = date('Y-m-d');
$time_now = date("H:i:s");

$s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = 'img/avatar-1.jpg';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = 'img/profile/'.$name ;
      }

?>

<!DOCTYPE html>
<html ng-app="myApp" ng-app lang="en" ng-controller="noticesCtrl">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Noticeboard | Announcements</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Font Awesome CDN-->
    <!-- you can replace it by local Font Awesome-->
    <script src="js/99347ac47f.js"></script>
    <!-- Font Icons CSS-->
    <link rel="stylesheet" href="css/icons.css">
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <?php

      if(isset($_POST['announce'])){

        $short_name = mysqli_real_escape_string($con, $_POST['short_name']);
        $announcement = mysqli_real_escape_string($con, $_POST['announcement']);
        $priority_level = mysqli_real_escape_string($con, $_POST['priority_level']);
        $today_date = mysqli_real_escape_string($con, $today);
        $today_time = mysqli_real_escape_string($con, $time_now);

        $post_announcement = mysqli_query($con, "insert into announcement (short_name,announcement,priority_level,today_date,today_time, admin_id) values ('$short_name','$announcement','$priority_level','$today_date','$today_time','$login_session_id')");

        if($post_announcement){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'You have been successfully posted an announcement.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'announcements.php';
                      });}
                      ,0);
                      </script>";
        }else{

          // echo "Error: ".mysqli_error($con);
          echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to post announcement. Please try again later!',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'announcements.php';
                      });}
                      ,0);
                      </script>";

        }

      }
    ?>
  </head>
  <body>
    <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <div class="sidenav-header-inner text-center"><img src="<?php echo $image;?>" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5 text-uppercase"><?php echo $login_session_name." ".$login_session_surname;?></h2><span class="text-uppercase">Administrator</span>
          </div>
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>O</strong><strong class="text-primary">N</strong></a></div>
        </div>
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li><a href="home.php"> <i class="icon-home"></i><span>Home</span></a></li>
            <li class="active"> <a href="announcements.php"><i class="icon-form"></i><span>Announcements</span></a></li>
            <li> <a href="create_account.php"> <i class="icon-interface-windows"></i><span>Create Account</span></a></li>
            <li> 
              <a href="#pages-nav-list" data-toggle="collapse" aria-expanded="false"><i class="icon-screen"></i><span>System Users</span>
                <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
              <ul id="pages-nav-list" class="collapse list-unstyled">
                <li> <a href="administrators.php">Administrators</a></li>
                <li> <a href="students.php">Students</a></li>
              </ul>
            </li>
            <li> <a href="profile.php"> <i class="icon-user"></i><span>User Profile</span></a></li>
            <li> 
               <a href="#pages-nav-list1" data-toggle="collapse" aria-expanded="false"> <i class="icon-list-1"></i><span>Reports</span>  <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div>
               </a>
               <ul id="pages-nav-list1" class="collapse list-unstyled">
                <li> <a href="admin_reports.php">Admin Reports</a></li>
                <li> <a href="student_reports.php">Student Reports</a></li>
              </ul>
            </li>
            <li> <a href="logout.php"> <i class="fa fa-sign-out"></i><span> Logout</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="page forms-page">
      <!-- navbar-->
      <header class="header">
        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="home.php" class="navbar-brand">
                  <div class="brand-text hidden-sm-down"><span>Administrator's </span><strong class="text-primary"> Dashboard</strong></div></a></div>
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a href="logout.php" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Announcements</li>
          </ul>
        </div>
      </div>
      <section class="forms">
        <div class="container-fluid">
          <header> 
            <h1 class="h3 display">Posted Announcements</h1>
          </header>
          <div class="row">
            
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <!-- <h2 class="h5 display">Posted Announcements</h2> -->
                  <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Create New </button>
                  <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                    <div role="document" class="modal-dialog">
                <form method="post" action="">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 id="exampleModalLabel"  align="center" class="modal-title">Create an Announcement</h5>
                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                              <label>Title</label>
                              <input type="text" name="short_name" placeholder="E.g. AAA" class="form-control">
                            </div>
                            <div class="form-group">
                              <label>Announcement</label>
                              <textarea type="text" name="announcement" class="form-control" rows="6"></textarea>
                            </div>
                            <div class="form-group">
                              <label>Priority Level</label>
                                <select name="priority_level" class="form-control">
                                  <option value="1">Level 1 (Low)</option>
                                  <option value="5">Level 5 (Middle)</option>
                                  <option value="10">Level 10 (High)</option>
                                </select>
                            </div>
                            <div class="form-group">
                              <label>Date</label>
                              <input type="text" name="today_date" value="<?php echo $today;?>" class="form-control" disabled="">
                            </div>
                            <!-- <div class="form-group">
                              <label>Time</label>
                              <input type="text" time="today_time" value="<?php echo $time_now;?>" class="form-control" disabled="">
                            </div> -->
                        </div>
                        <div class="modal-footer">
                          <button type="submit" name="announce" class="btn btn-primary">Post Announcement</button>
                          <button type="submit" data-dismiss="modal" class="btn btn-secondary">Cancel</button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                </div>
                <div class="card-block">

                <!--top thingy-->
                <div class="row padding">
                  <div class="col-md-2">PageSize:
                      <select ng-model="entryLimit" class="form-control">
                          <option>5</option>
                          <option>10</option>
                          <option>20</option>
                          <option>50</option>
                          <option>100</option>
                      </select>
                  </div>
                <div class="col-md-3">Search:
                    <input type="text" ng-model="search" ng-change="filter()" placeholder="Search" class="form-control" />
                </div>

                <div class="col-md-4">
                <br>
                    <h5>Filtered {{ filtered.length }} of {{ totalItems}} total Students</h5>
                </div> 
              </div>
                <!--top thingy end-->
                <div ng-show="filteredItems > 0">
                  <table class="display table table-striped table-bordered" id="example" cellspacing="0">
                    <thead>
                      <tr>
                        <th></th>
                        <th>#</th>
                        <th>Shortname</th>
                        <th style="word-wrap: break-word;max-width: 250px;">Announcement</th>
                        <th>Date Posted</th>
                        <th>Time Posted</th>
                        <th>Priority Level</th>
                        <th>View More</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr ng-repeat="data in filtered = (list | filter:search | orderBy : predicate :reverse) | startFrom:(currentPage-1)*entryLimit | limitTo:entryLimit">
                        <td><input type="checkbox" name="check[]" value="{{data.post_id}}"></td>
                        <th scope="row">{{data.post_id}}</th>
                        <td>{{data.short_name}}</td>
                        <td>{{data.announcement | limitTo:60}}...</td>
                        <td>{{data.today_date}}</td>
                        <td>{{data.today_time}}</td>
                        <td ng-if="data.priority_level == '1'">Low Level</td>
                        <td ng-if="data.priority_level == '5'">Middle Level</td>
                        <td ng-if="data.priority_level == '10'">High Level</td>
                        <td ng-if="data.admin_id == '<?php echo $login_session_id;?>'"><a href='view_more.php?id={{data.post_id}}' style='color:red;'>View More</a></td>
                        <td ng-if="data.admin_id != '<?php echo $login_session_id;?>'"><a href='view_more_not.php?id={{data.post_id}}' style='color:green;'>View More</a></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <!--end table -->

                <!--zvepasi-->
                  <div class="col-md-12" ng-show="filteredItems == 0">
                    <div class="col-md-12">
                        <h5>No students found</h5>
                    </div>
                  </div>

                  <div class="col-md-12" ng-show="filteredItems > 0">    
                      <div pagination="" page="currentPage" on-select-page="setPage(page)" boundary-links="true" total-items="filteredItems" items-per-page="entryLimit" class="pagination-small" previous-text="&laquo;" next-text="&raquo;"></div>
                  </div>
                  <!-- zvepasi end-->

                  <!--buttons for operations -->
                  <button type="submit" class="btn btn-secondary">Cancel</button>
                  <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-danger">Delete Selected</button>

                </div>
              </div>
            </div>
        </div>
      </section>
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Kraphtbox &copy; 2017</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Design by <a href="https://bootstrapious.com" class="external">Bootstrapious</a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script> 
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/front.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <!---->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='//www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>


    <script src="js/angular.min.js"></script>
    <script src="js/ui-bootstrap-tpls-0.10.0.min.js"></script>
    <script src="js/app.js"></script>

  </body>
</html>