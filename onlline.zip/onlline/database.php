<?php
$connection = mysqli_connect('localhost','root','','online_noticeboard') or die(mysqli_error($connection));
?>