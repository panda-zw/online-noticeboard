<?php
//Database connection
$con=mysqli_connect("localhost","root","","online_noticeboard") or die("Connection was not established");

?>
