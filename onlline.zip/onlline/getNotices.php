<?php
include ("session.php");
 
$query="select distinct c.post_id,c.short_name, c.announcement, c.priority_level,c.today_date,c.today_time,c.admin_id from announcement c order by c.today_date desc";
$result = mysqli_query($con, $query);
 
$arr = array();
if($result->num_rows > 0) {
 while($row = $result->fetch_assoc()) {
 $arr[] = $row; 
 }
}
# JSON-encode the response
$json_response = json_encode($arr);
 
// # Return the response
echo $json_response;
?>