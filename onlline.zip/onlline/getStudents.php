<?php
include ("session.php");
 
$query="select distinct c.username,c.firstname, c.surname, c.email_address,c.role,c.status,c.created_by,c.user_id,c.date_created,c.activation_code,c.phone_number from users c where c.role = 'Student' order by c.user_id";
$result = mysqli_query($con, $query);
 
$arr = array();
if($result->num_rows > 0) {
 while($row = $result->fetch_assoc()) {
 $arr[] = $row; 
 }
}
# JSON-encode the response
$json_response = json_encode($arr);
 
// # Return the response
echo $json_response;
?>