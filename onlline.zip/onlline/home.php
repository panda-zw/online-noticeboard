<?php

include("session.php");

$s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = 'img/avatar-1.jpg';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = 'img/profile/'.$name ;
      }

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Noticeboard | Welcome</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Font Awesome CDN-->
    <!-- you can replace it by local Font Awesome-->
    <script src="https://use.fontawesome.com/99347ac47f.js"></script>
    <!-- Font Icons CSS-->
    <link rel="stylesheet" href="https://file.myfontastic.com/da58YPMQ7U5HY8Rb6UxkNf/icons.css">
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <script type="text/javascript">
      function startTime() {
          var today = new Date();
          var h = today.getHours();
          var m = today.getMinutes();
          var s = today.getSeconds();
          m = checkTime(m);
          s = checkTime(s);
          document.getElementById('txt').innerHTML =
          h + ":" + m + ":" + s;
          var t = setTimeout(startTime, 500);
      }
      function checkTime(i) {
          if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
          return i;
      }
    </script>
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body onload="startTime()">
    <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <div class="sidenav-header-inner text-center"><img src="<?php echo $image;?>" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5 text-uppercase"><?php echo $login_session_name;?> <?php echo $login_session_surname;?></h2><span class="text-uppercase">Administrator</span>
          </div>
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>O</strong><strong class="text-primary">N</strong></a></div>
        </div>
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li class="active"><a href="home.php"> <i class="icon-home"></i><span>Home</span></a></li>
            <li> <a href="announcements.php"><i class="icon-form"></i><span>Announcements</span></a></li>   
            <li> <a href="create_account.php"> <i class="icon-interface-windows"></i><span>Create Account</span></a></li>
            <li> 
              <a href="#pages-nav-list" data-toggle="collapse" aria-expanded="false"><i class="icon-screen"></i><span>System Users</span>
                <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
              <ul id="pages-nav-list" class="collapse list-unstyled">
                <li> <a href="administrators.php">Administrators</a></li>
                <li> <a href="students.php">Students</a></li>
              </ul>
            </li>
            <li> <a href="profile.php"> <i class="icon-user"></i><span>User Profile</span></a></li>
            <li> 
               <a href="#pages-nav-list1" data-toggle="collapse" aria-expanded="false"> <i class="icon-list-1"></i><span>Reports</span>  <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div>
               </a>
               <ul id="pages-nav-list1" class="collapse list-unstyled">
                <li> <a href="admin_reports.php">Admin Reports</a></li>
                <li> <a href="student_reports.php">Student Reports</a></li>
              </ul>
            </li>
            <li> <a href="logout.php"> <i class="fa fa-sign-out"></i><span> Logout</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="page home-page">
      <!-- navbar-->
      <header class="header">
        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="home.php" class="navbar-brand">
                  <div class="brand-text hidden-sm-down"><span>Administrator's </span><strong class="text-primary"> Dashboard</strong></div></a></div>
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a href="logout.php" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <!-- Counts Section -->
      <section class="dashboard-counts section-padding">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-user"></i></div>
                <div class="name"><strong class="text-uppercase">Total Users</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_users = mysqli_query($con, "select * from users");
                      $count = mysqli_num_rows($get_all_users);
                      echo $count;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-padnote"></i></div>
                <div class="name"><strong class="text-uppercase">Administrators</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_admins = mysqli_query($con, "select * from users where role = 'Administrator'");
                      $count_a = mysqli_num_rows($get_all_admins);
                      echo $count_a;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-check"></i></div>
                <div class="name"><strong class="text-uppercase">Total Students</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_students = mysqli_query($con, "select * from users where role = 'Student'");
                      $count_s = mysqli_num_rows($get_all_students);
                      echo $count_s;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-bill"></i></div>
                <div class="name"><strong class="text-uppercase">Total Notices</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_posts = mysqli_query($con, "select * from announcement");
                      $count_p = mysqli_num_rows($get_all_posts);
                      echo $count_p;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-list-1"></i></div>
                <div class="name"><strong class="text-uppercase">Active Students</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_a_students = mysqli_query($con, "select * from users where role = 'Student' and status = '2'");
                      $count_sa = mysqli_num_rows($get_a_students);
                      echo $count_sa;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <!-- <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-list-1"></i></div>
                <div class="name"><strong class="text-uppercase"></strong><span>Last 7 days</span>
                  <div class="count-number">70</div>
                </div>
              </div>
            </div> -->
          </div>
        </div>
      </section>
      <!-- Header Section-->
    <!-- Statistics Section-->
      <section class="statistics section-padding section-no-padding-bottom">
        <div class="container-fluid">
          <div class="row d-flex align-items-stretch">
            <div class="col-lg-4">
              <!-- Income-->
              <div class="wrapper income text-center">
                <div class="icon"><i class="icon-clock"></i></div>
                <div class="number"><a href="#" id="txt"></a></div><strong class="text-primary">Time</strong>
                <p></p>
              </div>
            </div>
            <div class="col-lg-4">
              <!-- Monthly Usage-->
              <div class="wrapper data-usage">
                <h2 class="display h4">Monthly Usage</h2>
                <div class="row d-flex align-items-center">
                  <div class="col-sm-6">
                    <div id="progress-circle" class="d-flex align-items-center justify-content-center"></div>
                  </div>
                  <div class="col-sm-6"><strong class="text-primary">80.56 Gb</strong><small>Current Plan</small><span>100 Gb Monthly</span></div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing.</p>
              </div>
            </div>
            <div class="col-lg-4">
              <!-- User Actibity-->
              <div class="wrapper user-activity">
                <h2 class="display h4">User Activity</h2>
                <div class="number">210</div>
                <h3 class="h4 display">Social Users</h3>
                <div class="progress">
                  <div role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar bg-primary"></div>
                </div>
                <div class="page-statistics d-flex justify-content-between">
                  <div class="page-visites"><span>Pages Visites</span><strong>230</strong></div>
                  <div class="new-visites"><span>New Visites</span><strong>73.4%</strong></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Updates Section -->
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Kraphtbox &copy; 2017</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Design by <a href="https://bootstrapious.com" class="external">Bootstrapious</a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- Javascript files-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <!---->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='//www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>
  </body>
</html>