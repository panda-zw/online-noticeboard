<?php

include("session.php");
include("database.php");

$uid = $login_session_id;  // set your user id settings
$datetime_string = date('c',time());    
    
if(isset($_POST['action']) or isset($_GET['view']))
{
    if(isset($_GET['view']))
    {
        header('Content-Type: application/json');
        $start = mysqli_real_escape_string($connection,$_GET["start"]);
        $end = mysqli_real_escape_string($connection,$_GET["end"]);
        
        $result = mysqli_query($connection,"SELECT `id`, `start` ,`end` ,`title` FROM  `events` where (date(start) >= '$start' AND date(start) <= '$end')");
        while($row = mysqli_fetch_assoc($result))
        {
            $events[] = $row; 
        }
        echo json_encode($events); 
        exit;
    }
    elseif($_POST['action'] == "add")
    {   
        mysqli_query($connection,"INSERT INTO `events` (
                    `title` ,
                    `start` ,
                    `end` ,
                    `uid` 
                    )
                    VALUES (
                    '".mysqli_real_escape_string($connection,$_POST["title"])."',
                    '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["start"])))."',
                    '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["end"])))."',
                    '".mysqli_real_escape_string($connection,$uid)."'
                    )");
        header('Content-Type: application/json');
        echo '{"id":"'.mysqli_insert_id($connection).'"}';
        exit;
    }
    elseif($_POST['action'] == "update")
    {
        mysqli_query($connection,"UPDATE `events` set 
            `start` = '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["start"])))."', 
            `end` = '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["end"])))."' 
            where id = '".mysqli_real_escape_string($connection,$_POST["id"])."'");
        exit;
    }
    elseif($_POST['action'] == "delete") 
    {
        mysqli_query($connection,"DELETE from `events` where id = '".mysqli_real_escape_string($connection,$_POST["id"])."'");
        if (mysqli_affected_rows($connection) > 0) {
            echo "1";
        }
        exit;
    }
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Noticeboard | Welcome</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.muzinda.css" id="theme-stylesheet">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom stylesheet - for your changes-->
    <!-- <link rel="stylesheet" href="css/custom.css"> -->
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Font Awesome CDN-->
    <!-- you can replace it by local Font Awesome-->
    <script src="js/99347ac47f.js"></script>
    <!-- Font Icons CSS-->
    <link rel="stylesheet" href="css/icons.css">
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

    <script src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/script.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <!-- <link  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" > -->

    <link href="css/fullcalendar.css" rel="stylesheet" />
    <link href="css/fullcalendar.print.css" rel="stylesheet" media="print" />
    <script src="js/moment.min.js"></script>
    <script src="js/fullcalendar.js"></script>

    <script type="text/javascript">
      function startTime() {
          var today = new Date();
          var h = today.getHours();
          var m = today.getMinutes();
          var s = today.getSeconds();
          m = checkTime(m);
          s = checkTime(s);
          document.getElementById('txt').innerHTML =
          h + ":" + m ;
          var t = setTimeout(startTime, 500);
      }
      function checkTime(i) {
          if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
          return i;
      }
    </script>

    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body onload="startTime()">
    <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <div class="sidenav-header-inner text-center"><img src="<?php echo $image;?>" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5 text-uppercase"><?php echo $login_session_name;?> <?php echo $login_session_surname;?></h2><span class="text-uppercase">Administrator</span>
          </div>
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>O</strong><strong class="text-primary">N</strong></a></div>
        </div>
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li class="active"><a href="home.php"> <i class="icon-home"></i><span>Home</span></a></li>
            <li> <a href="announcements.php"><i class="icon-form"></i><span>Announcements</span></a></li>   
            <li> <a href="create_account.php"> <i class="icon-interface-windows"></i><span>Create Account</span></a></li>
            <li> 
              <a href="#pages-nav-list" data-toggle="collapse" aria-expanded="false"><i class="icon-screen"></i><span>System Users</span>
                <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
              <ul id="pages-nav-list" class="collapse list-unstyled">
                <li> <a href="administrators.php">Administrators</a></li>
                <li> <a href="students.php">Students</a></li>
              </ul>
            </li>
            <li> <a href="profile.php"> <i class="icon-user"></i><span>User Profile</span></a></li>
            <li> 
               <a href="#pages-nav-list1" data-toggle="collapse" aria-expanded="false"> <i class="icon-list-1"></i><span>Reports</span>  <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div>
               </a>
               <ul id="pages-nav-list1" class="collapse list-unstyled">
                <li> <a href="admin_reports.php">Admin Reports</a></li>
                <li> <a href="student_reports.php">Student Reports</a></li>
              </ul>
            </li>
            <li> <a href="logout.php"> <i class="fa fa-sign-out"></i><span> Logout</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="page home-page">
      <!-- navbar-->
      <header class="header">
        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="home.php" class="navbar-brand">
                  <div class="brand-text hidden-sm-down"><span>Administrator's </span><strong class="text-primary"> Dashboard</strong></div></a></div>
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a href="logout.php" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <!-- Counts Section -->
      <section class="dashboard-counts section-padding">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-user"></i></div>
                <div class="name"><strong class="text-uppercase">Total Users</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_users = mysqli_query($con, "select * from users");
                      $count = mysqli_num_rows($get_all_users);
                      echo $count;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-padnote"></i></div>
                <div class="name"><strong class="text-uppercase">Administrators</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_admins = mysqli_query($con, "select * from users where role = 'Administrator'");
                      $count_a = mysqli_num_rows($get_all_admins);
                      echo $count_a;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-check"></i></div>
                <div class="name"><strong class="text-uppercase">Total Students</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_students = mysqli_query($con, "select * from users where role = 'Student'");
                      $count_s = mysqli_num_rows($get_all_students);
                      echo $count_s;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-bill"></i></div>
                <div class="name"><strong class="text-uppercase">Total Notices</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_all_posts = mysqli_query($con, "select * from announcement");
                      $count_p = mysqli_num_rows($get_all_posts);
                      echo $count_p;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-list-1"></i></div>
                <div class="name"><strong class="text-uppercase">Active Students</strong><span>Since start</span>
                  <div class="count-number">
                    <?php
                      $get_a_students = mysqli_query($con, "select * from users where role = 'Student' and status = '2'");
                      $count_sa = mysqli_num_rows($get_a_students);
                      echo $count_sa;
                    ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-clock"></i></div>
                <div class="name"><strong class="text-uppercase">Current time</strong><span>_________________</span>
                  <div class="count-number">
                    <a href="#" id="txt"></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Header Section-->
    <!-- Statistics Section-->
      <section class="statistics section-no-padding-bottom">
        <div class="container-fluid">
          <div class="row d-flex align-items-stretch">
            <div class="col-lg-12">
              <!-- Monthly Usage-->
              <div class="wrapper text-center">
                <div id="calendar" style="color:white;"></div>
              </div>
            </div>

            <!-- Calendar modal-->
            <div id="createEventModal" class="modal fade" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <form method="post" action="add">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title">Add Event</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                      <div class="modal-body">
                            <div class="control-group">
                                <label class="control-label" for="inputPatient">Event:</label>
                                <div class="field desc">
                                    <input class="form-control" id="title" name="title" placeholder="Event" type="text" value="">
                                </div>
                            </div>
                            
                            <input type="hidden" id="startTime"/>
                            <input type="hidden" id="endTime"/>
                            
                        <div class="control-group">
                            <label class="control-label" for="when">When:</label>
                            <div class="controls controls-row" id="when" style="margin-top:5px;">
                            </div>
                        </div>
                        
                      </div>
                        <div class="modal-footer">
                          <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
                          <button type="submit" class="btn btn-primary" id="submitButton">Save</button>
                      </div>
                    </div>
                  </form>

              </div>
            </div>
            <!-- calendar modal end -->

            <!-- event details -->
            <div id="calendarModal" class="modal fade">
              <div class="modal-dialog">

                <form method="post" action="delete">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h4 class="modal-title">Event Details</h4>
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                      </div>
                      <div id="modalBody" class="modal-body">
                      <h4 id="modalTitle" class="modal-title"></h4>
                      <div id="modalWhen" style="margin-top:5px;"></div>
                      </div>
                      <input type="hidden" id="eventID"/>
                      <div class="modal-footer">
                          <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
                          <button type="submit" class="btn btn-primary" id="deleteButton">Delete</button>
                      </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- event details end -->


          </div>
        </div>
      </section>
      <!-- Updates Section -->
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Kraphtbox &copy; 2017</p>
            </div>
            <div class="col-sm-6 text-right">
              <!-- <p>Design by <a href="https://bootstrapious.com" class="external">Bootstrapious</a></p> -->
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- Javascript files-->
    
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <!-- <script src="js/charts-home.js"></script> -->
    <script src="js/front.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <!---->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='//www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>
  </body>
</html>