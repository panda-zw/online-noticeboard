<?php
session_start();
include ("database_connect/connection.php");
//login with roles



if(isset($_POST['login'])){
		$email=mysqli_real_escape_string($con,$_POST['inputEmail']);
		$pass=mysqli_real_escape_string($con,$_POST['inputPassword']);
		$result = mysqli_query($con, "SELECT * FROM users WHERE email_address='".$email."' AND password='".$pass."'");
		$row = $result->fetch_assoc();
		$test= $row['role'];
		$active = $row['status'];
		$id = $row['user_id'];
		$name = $row['firstname'];
		$surname = $row['surname'];



	// checking to see if the email exists
			$_SESSION['email_address']=$email;
			if($test =='Administrator'){
				$_SESSION['email_address']=$email;
				$_SESSION['last_login_time']= time();
				echo "<script>window.open('home.php','_self')</script>";

			}
			if($test=='Tutor')
			{
				$_SESSION['email_address']=$email;
				$_SESSION['last_login_time']= time();
				// $nguva = date('d-m-Y h:i:sa');
				// $query = "insert into logbook (name, surname, email, login) values ('$name','$surname','$email','$nguva')";
				// $insert = mysqli_query($con, $query);
				echo "<script>window.open('tutors/index.php','_self')</script>";

			}
			if($test=='Student')
			{
				if($active >= 1){
					$_SESSION['email_address']=$email;
					$_SESSION['last_login_time']= time();
					echo "<script>window.location.href='student/index.php'</script>";
				}else{
					//account activation
					$_SESSION['email_address']=$email;
					$_SESSION['last_login_time']= time();
					echo "<script>window.location.href='activation.php'</script>";
				}

			}
			if($test=='OPC')
			{
				if($active == 1){
					$_SESSION['email_address']=$email;
					$_SESSION['last_login_time']= time();
					echo "<script>window.location.href='cgu_opc/index.php'</script>";
				}else{
					//account activation
					$_SESSION['email_address']=$email;
					$_SESSION['last_login_time']= time();
					echo "<script>window.location.href='opc_activation.php'</script>";
				}

			}

		else {
			echo "<script>alert('Email or password is not correct, try again!')</script>";

		}
}
?>