-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2017 at 12:49 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_noticeboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `post_id` int(200) NOT NULL,
  `short_name` varchar(20) NOT NULL,
  `announcement` varchar(2000) NOT NULL,
  `priority_level` int(2) NOT NULL,
  `today_date` date NOT NULL,
  `today_time` time NOT NULL,
  `admin_id` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`post_id`, `short_name`, `announcement`, `priority_level`, `today_date`, `today_time`, `admin_id`) VALUES
(5, 'Test Note', 'This is a test note to make sure everything is working properly and to make sure when it posts to the user it displays the profile picture as well. This is to show how much of a genius i am in general when it comes to coding in PHP. Not only that but to show how much of a good designer I am. I make nice things in general', 10, '2017-11-12', '09:23:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `start` varchar(100) NOT NULL,
  `end` varchar(100) NOT NULL,
  `uid` int(20) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile_pics`
--

CREATE TABLE `profile_pics` (
  `pic_id` int(20) NOT NULL,
  `user_id` int(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `size` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_pics`
--

INSERT INTO `profile_pics` (`pic_id`, `user_id`, `file`, `type`, `size`) VALUES
(1, 1, '56995-94148-max-cooper-human-cover-final-2000-with-text3_1.jpg', 'image/jpeg', 1567),
(2, 21, '3619-79577-pieces16.jpg', 'image/jpeg', 470);

-- --------------------------------------------------------

--
-- Table structure for table `seen_notifications`
--

CREATE TABLE `seen_notifications` (
  `id` int(20) NOT NULL,
  `post_id` int(20) NOT NULL,
  `seen_status` int(20) NOT NULL,
  `by_who` int(20) NOT NULL,
  `date_seen` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seen_notifications`
--

INSERT INTO `seen_notifications` (`id`, `post_id`, `seen_status`, `by_who`, `date_seen`) VALUES
(7, 5, 0, 21, '2017-11-12'),
(8, 5, 1, 8, '2017-11-13');

-- --------------------------------------------------------

--
-- Table structure for table `sticky_note`
--

CREATE TABLE `sticky_note` (
  `note_id` int(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `sticky_note` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(20) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sticky_note`
--

INSERT INTO `sticky_note` (`note_id`, `title`, `sticky_note`, `date`, `user_id`, `status`) VALUES
(7, 'Trial Note', 'This is a trial note to make sure notes are working properly', '2017-11-12', 21, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `surname` varchar(200) NOT NULL,
  `email_address` varchar(20) NOT NULL,
  `role` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` int(2) NOT NULL,
  `created_by` int(20) NOT NULL,
  `date_created` date NOT NULL,
  `activation_code` varchar(20) NOT NULL,
  `phone_number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `firstname`, `surname`, `email_address`, `role`, `password`, `status`, `created_by`, `date_created`, `activation_code`, `phone_number`) VALUES
(1, 'pmapika', 'Panashe', 'Mapika', 'panashe@email.com', 'Administrator', 'password', 0, 0, '2017-11-01', '', ''),
(8, 'Student', 'Student', 'Student', 'student@email.com', 'Student', 'pasword', 2, 2, '2017-10-31', '67a75iu7', '+263773383308'),
(21, 'kingpanda_zw', 'Panashe', 'Mapika', 'mapikapnsh@gmail.com', 'Student', 'password', 1, 0, '2017-11-12', '27e79b71', '+263-773383308'),
(22, 'trial', 'trail', 'trial', 'trial@email.com', 'Student', 'password', 0, 0, '2017-11-12', '379df9cc', '+263-773383308');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_pics`
--
ALTER TABLE `profile_pics`
  ADD PRIMARY KEY (`pic_id`);

--
-- Indexes for table `seen_notifications`
--
ALTER TABLE `seen_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sticky_note`
--
ALTER TABLE `sticky_note`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `post_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `profile_pics`
--
ALTER TABLE `profile_pics`
  MODIFY `pic_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `seen_notifications`
--
ALTER TABLE `seen_notifications`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `sticky_note`
--
ALTER TABLE `sticky_note`
  MODIFY `note_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
