<?php
include("session.php");
require("fpdf/fpdf.php");


$get_administrators = mysqli_query($con, "select * from users where role='Administrator' order by user_id");
 class PDF extends FPDF
{
function Header()
{
    // Select Arial bold 15
    $this->SetFont('Times','B',15);
    // Move to the right
    $this->Cell(80);
    // Framed title
    #$this->Image("../fpdf/flag.png",100,0,15,10);
   $this->Cell(30,10,'Online Noticeboard',0,0,'C');
    // Line break
    $this->Ln(10);
}
function Footer()
{
    // Go to 2 cm from bottom
    $this->SetY(-20);
    // Select Arial italic 8
    $this->SetFont('Arial','I',12);
    // Print centered page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}
}
$pdf = new PDF();
$pdf->header = 0;
$pdf->AddPage();
$pdf->SetFillColor(232,232,232);
//Bold Font for Field Name
$pdf->SetFont('Times','B',10);
#$pdf->SetFont("Arial","B","U",16);
$pdf->Cell(0,10,"All Administrators",1,1,"C");
$pdf->Ln(2);

$pdf->Cell(12,8,'ID',1,0,'L',1);
#$pdf->SetX(65);
$pdf->Cell(25,8,'Username',1,0,'L',1);
$pdf->Cell(25,8,'First Name',1,0,'L',1);
$pdf->Cell(30,8,'Surname',1,0,'L',1);
$pdf->Cell(45,8,'Email',1,0,'L',1);
$pdf->Cell(30,8,'Role',1,0,'L',1);
$pdf->Cell(23,8,'Date Created',1,0,'L',1);


$pdf->Ln();
#$i++;
while($row = mysqli_fetch_array($get_administrators)):;
$pdf->SetFont('Times','',10);
#$pdf->Image(`zimpic.jpg`,45,220,15,10);
#$pdf->Cell(45,6,'$i',1,0,'L');
$pdf->Cell(12,8,$row['user_id'],1,0,'L');
$pdf->Cell(25,8,$row['username'],1,0,'L');
$pdf->Cell(25,8,$row['firstname'],1,0,'L');
$pdf->Cell(30,8,$row['surname'],1,0,'L');
$pdf->Cell(45,8,$row['email_address'],1,0,'L');
$pdf->Cell(30,8,$row['role'],1,0,'L');
$pdf->Cell(23,8,$row['date_created'],1,0,'L');


$pdf->Ln();
 endwhile;
$pdf->footer = 0;

$pdf->output();


?>
