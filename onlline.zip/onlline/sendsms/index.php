<?php
session_start();
/*
 * Filename : frello.php
 * Purpose : Example/Guide on how to send SMSes via the Frello API (v4). The API is restful and documentation is available online at
 *           http://docs.frello.co.zw/v4
 *
 * Dependencies : Frello_Helper.php - Simple Class with a few methods to use when sending messages,creating lists, sending messages to a list etc over
 *            the API.
 *
 * Author : Bakani Z.M Pilime - Lead Developer (@afrikancoder, http://fb.com/bzmpilime, https://github.com/bzmp125, http://goo.gl/ms4rcp)
 * Date : 27/07/16
 *
 */

//include or require the helper
require_once 'Frello_Helper.php';

const APP_ID = 'APP62399';
  const APP_SECRET = '8fe44164475162ec07f7031bb67f2d24b1068f51';

$frello = new Frello(APP_ID,APP_SECRET);

//To send an sms to a number, make sure the number begins with the country code and does not have '00' or '+' appended to it

$message = '12 Testing Yeah yeeah yeah';
$to = '263773383308';
           //263 is the country code for Zimbabwe

//Then use the send_message method to send a single message

if($frello->send_sms($message,$to)){
    //message has been sent successfully
    echo '<script> alert("Message has been sent");
	
	window.location="notify.php";
	
	</script>';
}else{
    //message wasnt sent...check frello->result
    echo "<pre>", print_r($frello->result), "</pre>";    
}
?>