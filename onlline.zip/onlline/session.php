<?php
   include('database_connect/connection.php');
   session_start();

   $user_check = $_SESSION['email_address'];


   $ses_sql = mysqli_query($con,"SELECT * FROM users WHERE email_address = '$user_check'");

   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

   $login_session = $row['username'];
   $login_session_id = $row['user_id'];
   $login_session_name = $row['firstname'];
   $login_session_role = $row['role'];
   $login_session_surname = $row['surname'];
   $login_session_email_address = $row['email_address'];
   $login_session_active = $row['status'];
   $login_session_cell = $row['phone_number'];



   $s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = 'img/avatar-1.jpg';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = 'img/profile/'.$name ;
      }


   if(!isset($_SESSION['email_address'])){
      header("location:index.php");
   }


?>
