<?php

include('../session.php');
$today = date('Y-m-d');
$get_notifications = mysqli_query($con, "select * from announcement order by today_date desc, today_time desc");

$s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = '../img/User_Avatar.png';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = '../img/profile/'.$name ;
      }
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
     <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Noticeboard | Student</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT CSS -->
     <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css' />
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

    
    <style type="text/css">
      .round { 

          border-radius: 50%; 

        }
    </style>
     <?php

     if(isset($_POST['mark_as_seen'])){

      $post_id = mysqli_real_escape_string($con, $_POST['post_id']);

      $insert_seen = mysqli_query($con, "insert into seen_notifications (post_id,by_who, date_seen) values('$post_id','$login_session_id','$today')");
      if($insert_seen){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Notice dismissed.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'all_notices.php';
                      });}
                      ,0);
                      </script>";
      }else{
        // echo "Error :".mysqli_error($con);
        echo "<script>setTimeout(function() {swal({title: 'Error',text: 'Failed to dismiss notice.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'all_notices.php';
                      });}
                      ,0);
                      </script>";
      } 
     }
     ?>

</head>
<body>
    <!--LOGO SECTION END-->
     <section class="sec-menu" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
              <span class="menu-open-icon">  <i class="fa fa-bars pull-left fa-2x b-clr"   ></i> </span>  <font class="pull-right" style="color:black;font-size:medium;"><b><?php echo $login_session_name." ".$login_session_surname;?> <img src="../img/<?php echo $image;?>" class="round" width="50" height="50"></b></font>   
                </div>
            </div>
        </div>
    </section>
       <div id="side-menu"  >

        <ul  >
             <li style="border-bottom:0px;">
             <a href="#" title="close"> <i class="fa fa-close fa-2x menu-close-icon b-clr"></i></a>
            </li>
            <li>
             <a href="index.php" title="Home"> <i class="fa fa-home fa-2x "></i> </a>
            </li>
            <li>
              <a href="all_notices.php" title="Pending Notifications"> <i class="fa fa-globe fa-2x "></i>  </a>
            </li>
            <li>
              <a href="seen_notices.php" title="Seen Notifications"><i class="fa fa-check fa-2x "></i>  </a>
            </li>
             <li>
              <a href="profile.php" title="Profile"> <i class="fa fa-user fa-2x "></i>  </a>
            </li>
            <li>
              <a href="sticky.php" title="Sticky Notes"> <i class="fa fa-file fa-2x "></i>  </a>
            </li>
            <li>
              <a href="logout.php" title="Logout"> <i class="fa fa-sign-out fa-2x "></i>  </a>
            </li>
            
        </ul>
           
    </div>
    <!--MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Online Notice Board</h4>                
            </div>

        </div>
             <div class="row " style="padding-bottom:40px;">
            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="index.php"><i class="fa fa-calendar fa-5x "></i></a> 
                 <h5> Today's Notices</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <i class="fa fa-globe fa-5x "></i> 
                 <h5> Pending Notifications</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="seen_notices.php"><i class="fa fa-check fa-5x "></i></a>
                 <h5> Seen Notifications </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="profile.php"><i class="fa fa-user fa-5x "></i></a>
                 <h5> Profile </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="sticky.php"><i class="fa fa-file fa-5x "></i></a>
                 <h5> Sticky Notes</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="logout.php"><i class="fa fa-sign-out fa-5x "></i></a>
                 <h5> Logout</h5> 
               </div>
            </div>
        </div>  
             <hr />
             <br />
             <div class="row text-center ">
              <?php
                while($row = mysqli_fetch_assoc($get_notifications)):;
                $priority = $row['priority_level'];
                if($priority == 1){
                  $color = "info";
                }elseif($priority == 5){
                  $color = "warning";
                }else{
                  $color = "danger";
                }
                $post_num = $row['post_id'];
                $check_post = mysqli_query($con, "select * from seen_notifications where post_id = '$post_num' and by_who = '$login_session_id'");
                $count = mysqli_num_rows($check_post);
                if($count == 1){


                }else{
              ?>
              <form method="post" action="">
               <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="alert alert-<?php echo $color;?> text-left">
                      <h4> NOTICE: <?php echo $row['short_name'];?></h4> 
                      <hr />
                        <!-- <i class="fa fa-warning fa-4x"></i> -->
                      <p>
                     <?php echo $row['announcement'];?>
                    </p><br>
                      <p><b><font style='font-size: x-small;color:black;'> 
                        <?php 
                          $admin = $row['admin_id'];
                          $get_admin = mysqli_query($con, "select * from users where user_id = '$admin'");
                          while($who = mysqli_fetch_assoc($get_admin)){
                            echo $who['firstname']." ".$who['surname']." @ ".$row['today_time']."</font>";
                          }
                        ?></b></p>
                      <hr />
                      <input type="hidden" name="post_id" value="<?php echo $row['post_id'];?>">
                      <div class="text-right">
                       <button type="submit" name="mark_as_seen" class="btn btn-<?php echo $color;?> text-right">Mark as seen <i class="fa fa-check"></i></button>
                       </div> 
                  </div>
                </div>
              </form>
              <?php }endwhile;?>

              </div>

             <hr />
             <br />
             <br />
             <!-- <div class="row" style="padding-bottom:40px;">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <ul class="media-list">
                     <li class="media">
                        <a class="pull-left" href="#">
                          <img class="media-object img-circle" src="assets/img/user2.png" alt="" />
                        </a>
                          <div class="media-body">
                            <h4 class="media-heading">Vestibulum et eros consectetur</h4>
                              <p>
                                Donec sit amet ligula enim. Duis vel condimentum massa.
                                Maecenas eget congue dui. Vestibulum et eros consectetur,
                                interdum nibh et, volutpat dolor.
                              </p>
                          </div>
                     </li>
                   <!-- COMMENT SECTION - ONE END-->
                  </ul>
                </div>
             </div> 
          </div>
        </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2017 Online Noticeboard | Panashe Mapika 
                </div>

            </div>
        </div>
    </section>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
     <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
