﻿<?php

include('session.php');
include("database.php");

$today = date('Y-m-d');

$uid = $login_session_id;  // set your user id settings
$datetime_string = date('c',time());    
    
if(isset($_POST['action']) or isset($_GET['view']))
{
    if(isset($_GET['view']))
    {
        header('Content-Type: application/json');
        $start = mysqli_real_escape_string($connection,$_GET["start"]);
        $end = mysqli_real_escape_string($connection,$_GET["end"]);
        
        $result = mysqli_query($connection,"SELECT `id`, `start` ,`end` ,`title` FROM  `events` where (date(start) >= '$start' AND date(start) <= '$end')");
        while($row = mysqli_fetch_assoc($result))
        {
            $events[] = $row; 
        }
        echo json_encode($events); 
        exit;
    }
    elseif($_POST['action'] == "add")
    {   
        mysqli_query($connection,"INSERT INTO `events` (
                    `title` ,
                    `start` ,
                    `end` ,
                    `uid` 
                    )
                    VALUES (
                    '".mysqli_real_escape_string($connection,$_POST["title"])."',
                    '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["start"])))."',
                    '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["end"])))."',
                    '".mysqli_real_escape_string($connection,$uid)."'
                    )");
        header('Content-Type: application/json');
        echo '{"id":"'.mysqli_insert_id($connection).'"}';
        exit;
    // }
    // elseif($_POST['action'] == "update")
    // {
    //     mysqli_query($connection,"UPDATE `events` set 
    //         `start` = '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["start"])))."', 
    //         `end` = '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["end"])))."' 
    //         where id = '".mysqli_real_escape_string($connection,$_POST["id"])."'");
    //     exit;
    // }
    // elseif($_POST['action'] == "delete") 
    // {
    //     mysqli_query($connection,"DELETE from `events` where id = '".mysqli_real_escape_string($connection,$_POST["id"])."'");
    //     if (mysqli_affected_rows($connection) > 0) {
    //         echo "1";
    //     }
    //     exit;
    // }
}
}
?>

<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Noticeboard | Student</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT CSS -->
     <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css' />

    <script src="../js/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script_student.js"></script>

    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script> -->
    <script src="assets/js/bootstrap.js"></script>

    <link href="../css/fullcalendar.css" rel="stylesheet" />
    <link href="../css/fullcalendar.print.css" rel="stylesheet" media="print" />
    <script src="../js/moment.min.js"></script>
    <script src="../js/fullcalendar.js"></script>


    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">


     <?php

     if(isset($_POST['mark_as_seen'])){

      $post_id = mysqli_real_escape_string($con, $_POST['post_id']);

      $insert_seen = mysqli_query($con, "insert into seen_notifications (post_id,by_who, date_seen) values('$post_id','$login_session_id','$today')");
      if($insert_seen){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Notice dismissed.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'all_notices.php';
                      });}
                      ,0);
                      </script>";
      }else{
        // echo "Error :".mysqli_error($con);
        echo "<script>setTimeout(function() {swal({title: 'Error',text: 'Failed to dismiss notice.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'all_notices.php';
                      });}
                      ,0);
                      </script>";
      } 
     }
     ?>

     <style type="text/css">
       
    .round { 

      border-radius: 50%; 

    }

    .card{
      width: 100%x;
      border: 1px solid gray;
      box-shadow: 1px 1px 3px #888;
      border-top: 10px solid #d89c24;
      min-height: 250px;
      padding-: 10px;
      margin: 10px;
      }

     </style>

</head>
<body>
    <!--LOGO SECTION END-->
     <section class="sec-menu" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
              <span class="menu-open-icon">  <i class="fa fa-bars pull-left fa-2x b-clr"   ></i> </span>  <font class="pull-right" style="color:black;font-size:medium;"><b><?php echo $login_session_name." ".$login_session_surname;?> <img src="../img/<?php echo $image;?>" class="round" width="50" height="50"></b></font>   
                </div>
            </div>
        </div>
    </section>
       <div id="side-menu"  >

        <ul  >
             <li style="border-bottom:0px;">
             <a href="#" title="close"> <i class="fa fa-close fa-2x menu-close-icon b-clr"></i></a>
            </li>
            <li>
             <a href="index.php" title="Home"> <i class="fa fa-home fa-2x "></i> </a>
            </li>
            <li>
              <a href="all_notices.php" title="All Notifications"> <i class="fa fa-globe fa-2x "></i>  </a>
            </li>
            <li>
              <a href="seen_notices.php" title="Seen Notifications"><i class="fa fa-check fa-2x "></i>  </a>
            </li>
             <li>
              <a href="profile.php" title="Profile"> <i class="fa fa-user fa-2x "></i>  </a>
            </li>
            <li>
              <a href="sticky.php" title="Sticky Notes"> <i class="fa fa-file fa-2x "></i>  </a>
            </li>
            <li>
              <a href="logout.php" title="Logout"> <i class="fa fa-sign-out fa-2x "></i>  </a>
            </li>
            
        </ul>
           
    </div>
    <!--MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Online Notice Board</h4>                
            </div>

        </div>
             <div class="row " style="padding-bottom:40px;">
            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <i class="fa fa-calendar fa-5x "></i> 
                 <h5> Today's Notices</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="all_notices.php"><i class="fa fa-globe fa-5x "></i></a> 
                 <h5> All Notifications</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="seen_notices.php"><i class="fa fa-check fa-5x "></i></a>
                 <h5> Seen Notifications </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="profile.php"><i class="fa fa-user fa-5x "></i></a>
                 <h5> Profile </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="sticky.php"><i class="fa fa-file fa-5x "></i></a>
                 <h5> Sticky Notes</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="logout.php"><i class="fa fa-sign-out fa-5x "></i></a>
                 <h5> Logout</h5> 
               </div>
            </div>
        </div>  
             <hr />
             <br />
             <div class="row text-center ">
              <form method="post" action="">
                <div class="col-md-12 col-xs-12 col-sm-12">
                  <div id="calendar"></div>
                </div>
              </form>

              <div id="calendarModal" class="modal fade">
                <div class="modal-dialog">
                <form method="post" action="delete">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Event Details</h4>
                        </div>
                        <div id="modalBody" class="modal-body">
                        <h4 id="modalTitle" class="modal-title"></h4>
                        <div id="modalWhen" style="margin-top:5px;"></div>
                        </div>
                        <input type="hidden" id="eventID"/>
                        <div class="modal-footer">
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
                            <!-- <button type="submit" class="btn btn-danger" id="deleteButton">Delete</button> -->
                        </div>
                    </div>
                </form>
                </div>
                </div>
              </div>


             <hr />
             <br />
             <br />
          </div>
        </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2017 Online Noticeboard | Panashe Mapika 
                </div>

            </div>
        </div>
    </section>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <!-- <script src="assets/js/jquery-1.11.1.js"></script> -->
    <!-- BOOTSTRAP SCRIPTS  -->
    <!-- <script src="assets/js/bootstrap.js"></script> -->
     <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
