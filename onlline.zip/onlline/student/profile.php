<?php

include('../session.php');
$today = date('Y-m-d');
$get_notifications = mysqli_query($con, "select * from announcement order by today_date desc, today_time desc");

$s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = '../img/User_Avatar.png';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = '../img/profile/'.$name ;
      }
      

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
     <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Noticeboard | Student</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT CSS -->
     <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css' />

    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

    <style type="text/css">
    .hovereffect {
      width: 100%;
      height: 100%;
      float: left;
      overflow: hidden;
      position: relative;
      text-align: center;
      cursor: default;
    }


    .hovereffect:hover .overlay {
      background-color: rgba(170,170,170,0.4);
    }

    .hovereffect h2, .hovereffect img {
      -webkit-transition: all 0.4s ease-in-out;
      transition: all 0.4s ease-in-out;
    }

    .hovereffect img {
      display: block;
      position: relative;
      -webkit-transform: scale(1.1);
      -ms-transform: scale(1.1);
      transform: scale(0.9);
    }

    .hovereffect:hover img {
      -webkit-transform: scale(1);
      -ms-transform: scale(1);
      transform: scale(1);
    }

    .hovereffect h2 {
      text-transform: uppercase;
      color: #fff;
      text-align: center;
      position: relative;
      font-size: 17px;
      padding: 10px;
      background: rgba(0, 0, 0, 0.6);
    }

    .hovereffect a.info {
      display: inline-block;
      text-decoration: none;
      padding: 7px 14px;
      text-transform: uppercase;
      color: #fff;
      border: 1px solid #fff;
      margin: 50px 0 0 0;
      background-color: transparent;
      opacity: 0;
      filter: alpha(opacity=0);
      -webkit-transform: scale(1.5);
      -ms-transform: scale(1.5);
      transform: scale(1.5);
      -webkit-transition: all 0.4s ease-in-out;
      transition: all 0.4s ease-in-out;
      font-weight: normal;
      height: 85%;
      width: 85%;
      position: absolute;
      top: -20%;
      left: 8%;
      padding: 70px;
    }
    .file {
      visibility: hidden;
      position: absolute;
    }

    .cropit-preview {
        background-color: #f8f8f8;
        background-size: cover;
        border: 1px solid #ccc;
        border-radius: 3px;
        margin-top: 7px;
        width: 250px;
        height: 250px;
      }

      .cropit-preview-image-container {
        cursor: move;
      }

      .image-size-label {
        margin-top: 10px;
      }

      input {
        display: block;
      }

      button[type="submit"] {
        margin-top: 10px;
      }

      #result {
        margin-top: 10px;
        width: 900px;
      }

      #result-data {
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        word-wrap: break-word;
      }

      .round { 

          border-radius: 50%; 

        }
  
  </style>

    <?php

      if(isset($_POST['update_details'])){

        $username = mysqli_real_escape_string($con, $_POST['username']);
        $firstname = mysqli_real_escape_string($con, $_POST['firstname']);
        $surname = mysqli_real_escape_string($con, $_POST['surname']);
        $email_address = mysqli_real_escape_string($con, $_POST['email_address']);

        $update_dets = mysqli_query($con, "update users set username = '$username', firstname = '$firstname', surname = '$surname' where user_id = '$login_session_id'");

        if($update_dets){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'You have been successfully updated your details.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'profile.php';
                      });}
                      ,0);
                      </script>";
        }else{

          echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to update details. Please try again later.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'profile.php';
                      });}
                      ,0);
                      </script>";

        }


      }

      if(isset($_POST['update_password'])){

        $old_password = mysqli_real_escape_string($con, $_POST['old_password']);
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

        $get_old_password = mysqli_query($con, "select * from users where user_id = '$login_session_id'");
        while($row = mysqli_fetch_assoc($get_old_password)):;
          if($row['password'] != $old_password){

            echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Old passwords do no match.',type: 'warning' ,confirmButtonText: 'close'},
                     function() {
                        window.location = 'profile.php';
                        });}
                        ,0);
                        </script>";
          }elseif($password != $cpassword){

            echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'New passwords do not match. Try again.',type: 'warning' ,confirmButtonText: 'close'},
                     function() {
                        window.location = 'profile.php';
                        });}
                        ,0);
                        </script>";
          }else{

            $update_p = mysqli_query($con, "update users set password = '$password' where user_id = '$login_session_id'");
            if($update_p){

              echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Password successfully updated.',type: 'success' ,confirmButtonText: 'close'},
                     function() {
                        window.location = 'profile.php';
                        });}
                        ,0);
                        </script>";

            }else{

              echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to update password.',type: 'error' ,confirmButtonText: 'close'},
                     function() {
                        window.location = 'profile.php';
                        });}
                        ,0);
                        </script>";

            }

          }
        endwhile;

      }

      if(isset($_POST['upload'])){

        $file = rand(1000,100000)."-".$_FILES['file']['name'];
        $file_loc = $_FILES['file']['tmp_name'];
        $file_size = $_FILES['file']['size'];
        $file_type = $_FILES['file']['type'];
        
        $folder="../img/profile/";
        
           // new file size in KB
        $new_size = $file_size/1024;  
        // new file size in KB

        // make file name in lower case
        $new_file_name = strtolower($file);
        // make file name in lower case

        $final_file=str_replace(' ','-',$new_file_name);
  
        if(move_uploaded_file($file_loc,$folder.$final_file))
        { 
          
          $find  = "select * from profile_pics where user_id = '$login_session_id'";
          $found = mysqli_query($con, $find);
    
    
          if($file_type != "image/jpg" && $file_type != "image/png" && $file_type != "image/jpeg" && $file_type != "image/gif" ) {

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.',type: 'warning' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'profile.php';
                      });}
                      ,0);
                      </script>";

          }else if(mysqli_num_rows($found) == 1){
            $sql = "UPDATE profile_pics SET file = '$final_file', type= '$file_type', size = '$new_size' where user_id = '$login_session_id'";
              mysqli_query($con,$sql);
              if($sql){

                  echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Successfully Updated your profile picture.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'profile.php';
                      });}
                      ,0);
                      </script>";

              
              }else{

                echo "<script>setTimeout(function() {swal({title: 'Error',text: 'Failed to upload profile picture. Please try again later.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'profile.php';
                      });}
                      ,0);
                      </script>";
              }

          }else{

             $sql="INSERT INTO profile_pics(user_id ,file ,type ,size) VALUES('$login_session_id','$final_file','$file_type','$new_size')";
            mysqli_query($con,$sql);
            if($sql){

                echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Successfully uploaded your profile picture.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'profile.php';
                      });}
                      ,0);
                      </script>";
              
            }else{

                  echo "<script>setTimeout(function() {swal({title: 'Error',text: 'Failed to upload your profile picture.',type: 'error' ,confirmButtonText: 'close'},
                         function() {
                            window.location = 'profile.php';
                            });}
                            ,0);
                            </script>";

              }
          }
           

      }

    }
    ?>

</head>
<body>
    <!--LOGO SECTION END-->
     <section class="sec-menu" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
              <span class="menu-open-icon">  <i class="fa fa-bars pull-left fa-2x b-clr"   ></i> </span>  <font class="pull-right" style="color:black;font-size:medium;"><b><?php echo $login_session_name." ".$login_session_surname;?> <img src="../img/<?php echo $image;?>" class="round" width="50" height="50"></b></font>   
                </div>
            </div>
        </div>
    </section>
       <div id="side-menu"  >

        <ul  >
             <li style="border-bottom:0px;">
             <a href="#" title="close"> <i class="fa fa-close fa-2x menu-close-icon b-clr"></i></a>
            </li>
            <li>
             <a href="index.php" title="Home"> <i class="fa fa-home fa-2x "></i> </a>
            </li>
            <li>
              <a href="all_notices.php" title="Pending Notifications"> <i class="fa fa-globe fa-2x "></i>  </a>
            </li>
            <li>
              <a href="seen_notices.php" title="Seen Notifications"><i class="fa fa-check fa-2x "></i>  </a>
            </li>
             <li>
              <a href="profile.php" title="Profile"> <i class="fa fa-user fa-2x "></i>  </a>
            </li>
            <li>
              <a href="sticky.php" title="Sticky Notes"> <i class="fa fa-file fa-2x "></i>  </a>
            </li>
            <li>
              <a href="logout.php" title="Logout"> <i class="fa fa-sign-out fa-2x "></i>  </a>
            </li>
            
        </ul>
           
    </div>
    <!--MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Online Notice Board</h4>                
            </div>

        </div>
             <div class="row " style="padding-bottom:40px;">
            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="index.php"><i class="fa fa-calendar fa-5x "></i></a> 
                 <h5> Today's Notices</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="all_notices.php"><i class="fa fa-globe fa-5x "></i></a>
                 <h5> Pending Notifications</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="seen_notices.php"><i class="fa fa-check fa-5x "></i></a>
                 <h5> Seen Notifications </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <i class="fa fa-user fa-5x "></i>
                 <h5> Profile </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="sticky.php"><i class="fa fa-file fa-5x "></i></a>
                 <h5> Sticky Notes</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="logout.php"><i class="fa fa-sign-out fa-5x "></i></a>
                 <h5> Logout</h5> 
               </div>
            </div>
        </div>  
             <hr />
             <br />
             <div class="row">
              
              <div class="col-md-4 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                  <div class="panel-heading">
                     User Profile Details
                  </div>
                  <div class="panel-body">
                      <form role="form" method="post" action="">
                        <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" name="username" value="<?php echo $login_session;?>" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>First Name</label>
                            <input class="form-control" name="firstname" value="<?php echo $login_session_name;?>" type="text" required/>
                        </div>
                        <div class="form-group">
                            <label>Surname</label>
                            <input class="form-control" name="surname" value="<?php echo $login_session_surname;?>" type="text" required/>
                        </div>
                         <div class="form-group">
                            <label>Enter Email</label>
                            <input class="form-control" name="email_address" value="<?php echo $login_session_email_address;?>" type="email" required readonly/>
                          </div>
                        <button type="submit" name="update_details" class="btn btn-info">Update Details </button>
                      </form>
                  </div>
                </div>
            </div>

              <div class="col-md-4 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                  <div class="panel-heading">
                     Update Password
                  </div>
                  <div class="panel-body">
                    <form role="form" method="post" action="">
                      <div class="form-group">
                        <label>Old Password</label>
                        <input class="form-control" type="password" name="old_password" required/>
                        <p class="help-block">Type your old password here.</p>
                      </div>
                      <div class="form-group">
                        <label>New Password</label>
                        <input class="form-control" type="password" name="password" required/>
                        <p class="help-block">Type your new password here.</p>
                      </div>
                      <div class="form-group">
                        <label>Confirm Password</label>
                        <input class="form-control" type="password" name="cpassword" required/>
                        <p class="help-block">Retype new password here.</p>
                      </div>
                      <button type="submit" name="update_password" class="btn btn-info">Update Password </button>
                    </form>
                  </div>
                </div>
              </div>


              <div class="col-md-1 col-sm-6 col-xs-12">
              </div>

              <div class="col-lg-3">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display"></h2>
                </div>
                <div class="card-block">
                   <!-- new code for profile pic-->  
        <div class="text-center">
          <div class="hovereffect">
              <img src="<?php echo $image;?>" id="pop" class="center-block img-circle img-responsive" height="350" width="350">
              <span><font style="color:red;">Note*</font> Click on image to upload profile pic. Image must have equal dimensions to display properly.</span>
          </div><br>
        </div>

          <div class="modal fade text-center" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content text-center">
                <div class="modal-header text-center" align="center" > 
                  <h4 class="modal-title" id="myModalLabel"></h4><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                </div>
                <div class="modal-body" align="center">
                  <img src="<?php echo $image;?>" class="cropit-preview" style="width: 400px; height: 400px;" >
                </div>
                  <form action="" method="post" attribute enctype="multipart/form-data">
                  <div class="modal-footer">
                  <label class="btn btn-blue btn-default">
                      <input type="file" name="file" class="cropit-image-input" value="Choose image to upload"/>
                  </label>
                    <button type="submit" name="upload" class="btn btn-success">Upload</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- end new code -->
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2017 Online Noticeboard | Panashe Mapika 
                </div>

            </div>
        </div>
    </section>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script>
      $("#pop").on("click", function() {
      $('#imagepreview').attr('src', $('#imageresource').attr('src')); // here asign the image to the modal when the user click the enlarge link
      $('#imagemodal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
      });
    </script>

    <script>
  $('#image-cropper').cropit();

// In the demos I'm passing in an imageState option
// so it renders an image by default:
// $('#image-cropper').cropit({ imageState: { src: { imageSrc } } });

// Exporting cropped image
    $('.download-btn').click(function() {
      var imageData = $('#image-cropper').cropit('export');
      window.open(imageData);
    });
  </script>

    <script type="text/javascript">
      $(document).on('click', '.browse', function(){
      var file = $(this).parent().parent().parent().find('.file');
      file.trigger('click');
    });
    $(document).on('change', '.file', function(){
      $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
    });
    </script>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
     <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
