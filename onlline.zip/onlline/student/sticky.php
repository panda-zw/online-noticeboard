<?php

include('../session.php');
$today = date('Y-m-d');
$get_notes = mysqli_query($con, "select * from sticky_note where user_id = '$login_session_id' and status = '0' order by date asc");
$count = mysqli_num_rows($get_notes);
      $s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = '../img/User_Avatar.png';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = '../img/profile/'.$name ;
      }
?>

<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Online Noticeboard | Student</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT CSS -->
     <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css' />
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

    <style type="text/css">
      .round { 

          border-radius: 50%; 

        }


    .card{
      width: 100%x;
      border: 1px solid gray;
      box-shadow: 1px 1px 3px #888;
      border-top: 10px solid #d88a23;
      min-height: 150px;
      padding-: 10px;
      margin: 10px;
      }


    </style>
     <?php

     if(isset($_POST['delete_note'])){

      $note_id = mysqli_real_escape_string($con, $_POST['note_id']);
      $status = 1;
      $insert_seen = mysqli_query($con, "update sticky_note set status = '$status' where note_id = '$note_id' and user_id = '$login_session_id'");
      if($insert_seen){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Note deleted successfully.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'sticky.php';
                      });}
                      ,0);
                      </script>";
      }else{
        // echo "Error :".mysqli_error($con);
        echo "<script>setTimeout(function() {swal({title: 'Error',text: 'Failed to delete note.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'sticky.php';
                      });}
                      ,0);
                      </script>";
      } 
     }

     if(isset($_POST['note'])){

     	$title = mysqli_real_escape_string($con, $_POST['title']);
     	$sticky_note = mysqli_real_escape_string($con, $_POST['sticky_note']);
     	$date = mysqli_real_escape_string($con, $today);

     	$insert_note = mysqli_query($con, "insert into sticky_note (title, sticky_note, date, user_id) values ('$title','$sticky_note','$date','$login_session_id')");
     	if($insert_note){

     		echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Note added successfully.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'sticky.php';
                      });}
                      ,0);
                      </script>";
     	}else{
     		echo "Error: ".mysqli_error($con);
     		echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to add note. Try again later.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'sticky.php';
                      });}
                      ,0);
                      </script>";

     	}

     }
     ?>

</head>
<body>
    <!--LOGO SECTION END-->
     <section class="sec-menu" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
              <span class="menu-open-icon">  <i class="fa fa-bars pull-left fa-2x b-clr"   ></i> </span>  <font class="pull-right" style="color:black;font-size:medium;"><b><?php echo $login_session_name." ".$login_session_surname;?> <img src="../img/<?php echo $image;?>" class="round" width="50" height="50"></b></font>   
                </div>
            </div>
        </div>
    </section>
       <div id="side-menu"  >

        <ul  >
             <li style="border-bottom:0px;">
             <a href="#" title="close"> <i class="fa fa-close fa-2x menu-close-icon b-clr"></i></a>
            </li>
            <li>
             <a href="index.php" title="Home"> <i class="fa fa-home fa-2x "></i> </a>
            </li>
            <li>
              <a href="all_notices.php" title="Pending Notifications"> <i class="fa fa-globe fa-2x "></i>  </a>
            </li>
            <li>
              <a href="seen_notices.php" title="Seen Notifications"><i class="fa fa-check fa-2x "></i>  </a>
            </li>
             <li>
              <a href="profile.php" title="Profile"> <i class="fa fa-user fa-2x "></i>  </a>
            </li>
            <li>
              <a href="sticky.php" title="Sticky Notes"> <i class="fa fa-file fa-2x "></i>  </a>
            </li>
            <li>
              <a href="logout.php" title="Logout"> <i class="fa fa-sign-out fa-2x "></i>  </a>
            </li>
            
        </ul>
           
    </div>
    <!--MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Online Notice Board</h4>                
            </div>

        </div>
             <div class="row " style="padding-bottom:40px;">
            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="index.php"><i class="fa fa-calendar fa-5x "></i></a> 
                 <h5> Today's Notices</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="all_notices.php"><i class="fa fa-globe fa-5x "></i></a> 
                 <h5> All Notifications</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="seen_notices.php"><i class="fa fa-check fa-5x "></i></a> 
                 <h5> Seen Notifications </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="profile.php"><i class="fa fa-user fa-5x "></i></a>
                 <h5> Profile </h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <i class="fa fa-file fa-5x "></i>
                 <h5> Sticky Notes</h5> 
               </div>
            </div>

            <div class="col-md-2 col-sm-2 col-xs-6">
               <div class="text-center">
                  <a href="logout.php"><i class="fa fa-sign-out fa-5x "></i></a>
                 <h5> Logout</h5> 
               </div>
            </div>
        </div>  
             <hr />
             &nbsp;&nbsp;&nbsp;<button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Create New <i class="fa fa-plus"></i></button>
             <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                    <div role="document" class="modal-dialog">
                <form method="post" action="">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 id="exampleModalLabel"  align="center" class="modal-title">Create an Note</h5>
                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                              <label>Title</label>
                              <input type="text" name="title" placeholder="E.g. Must what" class="form-control">
                            </div>
                            <div class="form-group">
                              <label>Note</label>
                              <textarea type="text" name="sticky_note" class="form-control" rows="4" maxlength="200"></textarea>
                              <span class="pull-right">Note* <font style="color: red;">Max length 200</font></span>
                            </div>
                            <div class="form-group">
                              <label>Date</label>
                              <input type="text" name="date" value="<?php echo $today;?>" class="form-control" readonly>
                            </div>
                            <!-- <div class="form-group">
                              <label>Time</label>
                              <input type="text" time="today_time" value="<?php echo $time_now;?>" class="form-control" disabled="">
                            </div> -->
                        </div>
                        <div class="modal-footer">
                          <button type="submit" name="note" class="btn btn-primary">Post Announcement</button>
                          <button type="submit" data-dismiss="modal" class="btn btn-secondary">Cancel</button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
             <br />
             <!--sticky note-->
             <?php
             if($count == 0){
             	echo "<h4 class='text-center'>No notes have been added.</h4>";
             }else{

             while($row = mysqli_fetch_assoc($get_notes)):;
             $note_id = $row['note_id'];
             ?>
             <form method="post" action="">
             <div class="card" style="padding-bottom:40px;">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <ul class="media-list">
                     <li class="media">
                      <br>
                        <a class="pull-left" href="#">
                          <img class="media-object img-circle" src="<?php echo $image;?>" width="50" height="50" alt="" />
                        </a>
                          <div class="media-body">
                            <h4 class="media-heading"><?php echo $row['title'];?></h4>
                              <p>
                                <?php echo $row['sticky_note'];?>
                              </p>
                          </div>
                     </li>
                  </ul>
                  <input type="hidden" name="note_id" value="<?php echo $note_id;?>">
                  <font style="font-size:x-small;"><?php echo $row['date'];?></font>
                  	<button type="submit" name="delete_note" class="btn btn-primary pull-right">Delete <i class="fa fa-trash"></i></button>
                </div>
             </div>
             </form>
             <br>
         <?php endwhile;
         }?>
             <!--sticky note end-->
             <hr />
             <br />
             <br />
            </div>
        </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2017 Online Noticeboard | Panashe Mapika 
                </div>

            </div>
        </div>
    </section>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
     <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
