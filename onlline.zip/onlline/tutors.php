<?php

include('session.php');

$get_tutors = mysqli_query($con, "select * from users where role='Tutor'");
$s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = 'img/avatar-1.jpg';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = 'img/profile/'.$name ;
      }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Noticeboard | Tutors</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Font Awesome CDN-->
    <!-- you can replace it by local Font Awesome-->
    <script src="js/99347ac47f.js"></script>
    <!-- Font Icons CSS-->
    <link rel="stylesheet" href="css/icons.css">
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->

    <?php

      if(isset($_POST['delete_tutor'])){

        if(!empty($_POST['checked'])){
        // Loop to store and display values of individual checked checkbox.
        foreach($_POST['checked'] as $selected){

        $delete_selected = mysqli_query($con, "delete from users where user_id = '$selected'");

        }

        if($delete_selected){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Selected tutors successfully deleted.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'tutors.php';
                      });}
                      ,0);
                      </script>";
        }else{

          echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to delete selected tutors. Try again later.',type: 'error' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'tutors.php';
                      });}
                      ,0);
                      </script>";

        }

      }
    }
    ?>

  </head>
  <body>
    <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <div class="sidenav-header-inner text-center"><img src="<?php echo $image;?>" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5 text-uppercase"><?php echo $login_session_name." ".$login_session_surname;?></h2><span class="text-uppercase">Administrator</span>
          </div>
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>O</strong><strong class="text-primary">N</strong></a></div>
        </div>
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li><a href="home.php"> <i class="icon-home"></i><span>Home</span></a></li>
            <li> <a href="announcements.php"><i class="icon-form"></i><span>Announcements</span></a></li>
            <li> <a href="create_account.php"> <i class="icon-interface-windows"></i><span>Create Account</span></a></li>
            <li> 
              <a href="#pages-nav-list" data-toggle="collapse" aria-expanded="false"><i class="icon-screen"></i><span>System Users</span>
                <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
              <ul id="pages-nav-list" class="collapse list-unstyled">
                <li> <a href="administrators.php">Administrators</a></li>
                <li class="active"> <a href="tutors.php">Tutors</a></li>
                <li> <a href="students.php">Students</a></li>
              </ul>
            </li>
            <li> <a href="profile.php"> <i class="icon-user"></i><span>User Profile</span></a></li>
            <li> <a href="inbox.php"> <i class="icon-mail"></i><span>Inbox</span>
                <div class="badge badge-warning">6 New</div></a></li>
            <li> <a href="logout.php"> <i class="fa fa-sign-out"></i><span> Logout</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="page forms-page">
      <!-- navbar-->
      <header class="header">
        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="home.php" class="navbar-brand">
                  <div class="brand-text hidden-sm-down"><span>Administrator's </span><strong class="text-primary"> Dashboard</strong></div></a></div>
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a href="logout.php" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item">System Users</li>
            <li class="breadcrumb-item active">Tutors</li>
          </ul>
        </div>
      </div>
      <section class="forms">
        <div class="container-fluid">
          <header> 
            <h1 class="h3 display">Tutors</h1>
          </header>
          <div class="row">
            
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <!-- <h2 class="h5 display">Posted Announcements</h2> -->
                </div>
                <div class="card-block">
                  <form method="post" action="">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th></th>
                        <th>#</th>
                        <th>Username</th>
                        <th>First Name</th>
                        <th>Surname</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Created By</th>
                        <th>Date Created</th>
                      </tr>
                    </thead>
                    <?php
                    while($row = mysqli_fetch_array($get_tutors)):;
                      $person = $row['created_by'];
                      $get_user = mysqli_query($con, "select * from users where user_id = '$person'");
                    ?>
                    <tbody>
                      <tr>
                        <th><input type="checkbox" name="checked[]" value="<?php echo $row['user_id'];?>"></th>
                        <th scope="row"><?php echo $row['user_id'];?></th>
                        <td><?php echo $row['username'];?></td>
                        <td><?php echo $row['firstname'];?></td>
                        <td><?php echo $row['surname'];?></td>
                        <td><?php echo $row['email_address'];?></td>
                        <td><?php echo $row['role'];?></td>
                        <td><?php 
                          while($user = mysqli_fetch_assoc($get_user)){
                            echo $user['firstname']." ".$user['surname'];
                          }
                        ?></td>
                        <td><?php echo $row['date_created'];?></td>
                      </tr>
                    </tbody>
                  <?php endwhile?>
                  </table>
                    <button type="submit" class="btn btn-secondary">Cancel</button>
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-danger">Delete Selected</button>
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                    <div role="document" class="modal-dialog"> 
                    <form method="post" action="">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 id="exampleModalLabel"  align="center" class="modal-title">Are you sure you want to delete selected tutors?</h5>
                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                        </div>
                        <!-- <div class="modal-body">

                        </div> -->
                        <div class="modal-footer">
                          <button type="submit" name="delete_tutor" class="btn btn-primary">Delete Selected</button>
                          <button type="submit" data-dismiss="modal" class="btn btn-secondary">Cancel</button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                </form>
                </div>
              </div>
            </div>
        </div>
      </section>
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Kraphtbox &copy; 2017</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Design by <a href="https://bootstrapious.com" class="external">Bootstrapious</a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/front.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <!---->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='//www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>
  </body>
</html>