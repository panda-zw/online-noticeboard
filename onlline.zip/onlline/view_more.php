<?php

include('session.php');

$post_id = $_GET['id'];

$get_announcement = mysqli_query($con, "select * from announcement where post_id='$post_id'");
$today = date('Y-m-d');
$time_now = date("H:i:s");


$s = "select * from profile_pics where user_id = '$login_session_id'";
      $ex = mysqli_query($con, $s);
      if(mysqli_num_rows($ex) == 0){

        $image = 'img/avatar-1.jpg';

      }else{
        while($r = mysqli_fetch_assoc($ex)){
        $name = $r['file'];
        }
        $image = 'img/profile/'.$name ;
      }

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Online Noticeboard | Create Account</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Font Awesome CDN-->
    <!-- you can replace it by local Font Awesome-->
    <script src="js/99347ac47f.js"></script>
    <!-- Font Icons CSS-->
    <link rel="stylesheet" href="css/icons.css">
    <script src="dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

    <?php

      if(isset($_POST['update_post'])){

        $short_name = mysqli_real_escape_string($con, $_POST['short_name']);
        $announcement = mysqli_real_escape_string($con, $_POST['announcement']);
        $today_date = mysqli_real_escape_string($con, $today);
        $today_time = mysqli_real_escape_string($con, $time_now);

        $update_ann = mysqli_query($con, "update announcement set short_name = '$short_name', announcement = '$announcement', today_date = '$today_date', today_time = '$today_time' where post_id = '$post_id'");

        if($update_ann){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Announcement successfully updated.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'view_more.php?id=$post_id';
                      });}
                      ,0);
                      </script>";

        }else{

          // echo "Error :".mysqli_error($con);
          echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to update post. Try again later.',type: 'error' ,confirmButtonText: 'close'},
                   function() {                  
                      window.location = 'view_more.php?id=$post_id';
                      });}
                      ,0);
                      </script>";

        }

      }

      if(isset($_POST['delete_post'])){

        $delete_post = mysqli_query($con, "delete from announcement where post_id = '$post_id'");

        if($delete_post){

          echo "<script>setTimeout(function() {swal({title: 'Success',text: 'Post successfully deleted.',type: 'success' ,confirmButtonText: 'close'},
                   function() {
                      window.location = 'announcements.php';
                      });}
                      ,0);
                      </script>";

        }else{

          echo "<script>setTimeout(function() {swal({title: 'Sorry',text: 'Failed to delete post. Try again later.',type: 'error' ,confirmButtonText: 'close'},
                   function() {                  
                      window.location = 'announcements.php';
                      });}
                      ,0);
                      </script>";
        }
      }

    ?>
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- Side Navbar -->
    <nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <div class="sidenav-header-inner text-center"><img src="<?php echo $image;?>" alt="person" class="img-fluid rounded-circle">
            <h2 class="h5 text-uppercase"><?php echo $login_session_name." ".$login_session_surname;?></h2><span class="text-uppercase">Administrator</span>
          </div>
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> <strong>O</strong><strong class="text-primary">N</strong></a></div>
        </div>
        <div class="main-menu">
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li><a href="home.php"> <i class="icon-home"></i><span>Home</span></a></li>
            <li class="active"> <a href="announcements.php"><i class="icon-form"></i><span>Announcements</span></a></li>   
            <li> <a href="create_account.php"> <i class="icon-interface-windows"></i><span>Create Account</span></a></li>
            <li> 
              <a href="#pages-nav-list" data-toggle="collapse" aria-expanded="false"><i class="icon-screen"></i><span>System Users</span>
                <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
              <ul id="pages-nav-list" class="collapse list-unstyled">
                <li> <a href="administrators.php">Administrators</a></li>
                <li> <a href="students.php">Students</a></li>
              </ul>
            </li>
            <li> <a href="profile.php"> <i class="icon-user"></i><span>User Profile</span></a></li>
            <li> 
               <a href="#pages-nav-list1" data-toggle="collapse" aria-expanded="false"> <i class="icon-list-1"></i><span>Reports</span>  <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div>
               </a>
               <ul id="pages-nav-list1" class="collapse list-unstyled">
                <li> <a href="admin_reports.php">Admin Reports</a></li>
                <li> <a href="student_reports.php">Student Reports</a></li>
              </ul>
            </li>
            <li> <a href="logout.php"> <i class="fa fa-sign-out"></i><span> Logout</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="page forms-page">
      <!-- navbar-->
      <header class="header">
        <nav class="navbar">
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <div class="navbar-header"><a id="toggle-btn" href="#" class="menu-btn"><i class="icon-bars"> </i></a><a href="home.php" class="navbar-brand">
                  <div class="brand-text hidden-sm-down"><span>Administrator's </span><strong class="text-primary"> Dashboard</strong></div></a></div>
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <li class="nav-item"><a href="logout.php" class="nav-link logout">Logout<i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="announcements.php">Announcements</a></li>
            <li class="breadcrumb-item active">Announcement Details</li>
          </ul>
        </div>
      </div>
      <section class="forms">
        <div class="container-fluid">
          <header> 
            <h1 class="h3 display">Announcement Details</h1>
          </header>
          <div class="row">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display"></h2>
                </div>
                <div class="card-block">
                  <form method="post" action="" class="form-horizontal">
                    <?php
                    while($row = mysqli_fetch_assoc($get_announcement)):;
                      ?>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Announcement ID<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="" value="<?php echo $post_id;?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Posted BY<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="" value="<?php echo $login_session_name." ".$login_session_surname;?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Short Name<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="short_name" value="<?php echo $row['short_name'];?>" class="form-control">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Announcement<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <textarea type="text" name="announcement" class="form-control" rows="6"><?php echo $row['announcement'];?></textarea>
                      </div>
                    </div>
                    <div class="line"></div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Date Posted<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="" value="<?php echo $row['today_date'];?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label">Time Posted<font style="color: red;"> *</font></label>
                      <div class="col-sm-10">
                        <input type="text" name="" value="<?php echo $row['today_time'];?>" class="form-control" readonly>
                      </div>
                    </div>
                    <div class="line"></div>
                    <div class="form-group row">
                      <div class="col-sm-4 offset-sm-2">
                        <button type="submit" class="btn btn-secondary">Cancel</button>
                        <button type="submit" name="update_post" class="btn btn-primary">Update Post</button>
                        <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-danger">Delete Post</button>
                      </div>
                    </div>
                  <?php endwhile;?>

                  <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                    <div role="document" class="modal-dialog">
                    <form method="post" action="">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 id="exampleModalLabel"  align="center" class="modal-title">Are you sure you want to delete this Announcement?</h5>
                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                        </div>
                        <!-- <div class="modal-body">

                        </div> -->
                        <div class="modal-footer">
                          <button type="submit" name="delete_post" class="btn btn-primary">Delete Post</button>
                          <button type="submit" data-dismiss="modal" class="btn btn-secondary">Cancel</button>
                        </div>
                      </div>
                    </form>
                    </div>
                  </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Kraphtbox &copy; 2017</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Design by <a href="https://bootstrapious.com" class="external">Bootstrapious</a></p>
              <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
            </div>
          </div>
        </div>
      </footer>
    </div>
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/front.js"></script>
    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.-->
    <!---->
    <script>
      (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
      function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
      e=o.createElement(i);r=o.getElementsByTagName(i)[0];
      e.src='//www.google-analytics.com/analytics.js';
      r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
      ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>
  </body>
</html>